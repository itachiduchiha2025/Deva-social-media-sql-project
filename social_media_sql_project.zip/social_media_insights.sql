
-- SOCIAL MEDIA INSIGHTS PROJECT

-- Drop existing tables if any
DROP TABLE IF EXISTS Likes;
DROP TABLE IF EXISTS Comments;
DROP TABLE IF EXISTS Followers;
DROP TABLE IF EXISTS Posts;
DROP TABLE IF EXISTS Users;

-- USERS TABLE
CREATE TABLE Users (
    user_id INT PRIMARY KEY,
    username VARCHAR(100),
    join_date DATE
);

-- POSTS TABLE
CREATE TABLE Posts (
    post_id INT PRIMARY KEY,
    user_id INT,
    content TEXT,
    post_date DATE,
    likes_count INT,
    comments_count INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- FOLLOWERS TABLE
CREATE TABLE Followers (
    follower_id INT,
    followed_id INT,
    FOREIGN KEY (follower_id) REFERENCES Users(user_id),
    FOREIGN KEY (followed_id) REFERENCES Users(user_id)
);

-- COMMENTS TABLE
CREATE TABLE Comments (
    comment_id INT PRIMARY KEY,
    post_id INT,
    user_id INT,
    content TEXT,
    comment_date DATE,
    FOREIGN KEY (post_id) REFERENCES Posts(post_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- LIKES TABLE
CREATE TABLE Likes (
    like_id INT PRIMARY KEY,
    post_id INT,
    user_id INT,
    like_date DATE,
    FOREIGN KEY (post_id) REFERENCES Posts(post_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- INSERTING SAMPLE USERS
INSERT INTO Users VALUES
(1, 'Deva', '2023-01-15'),
(2, 'Nataraj', '2023-02-10'),
(3, 'Vicky', '2023-02-25'),
(4, 'Yuvaraj', '2023-03-01'),
(5, 'Suman', '2023-04-05');

-- INSERTING SAMPLE POSTS
INSERT INTO Posts VALUES
(1, 1, 'Enjoying the sunshine today!', '2023-05-01', 10, 2),
(2, 2, 'Just finished a marathon!', '2023-05-02', 20, 5),
(3, 3, 'New blog post on SQL joins.', '2023-05-03', 5, 1),
(4, 4, 'What’s your favorite programming language?', '2023-05-04', 15, 4),
(5, 5, 'Check out this cool tech article!', '2023-05-05', 7, 2);

-- FOLLOWERS
INSERT INTO Followers VALUES
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(1, 3),
(2, 3),
(1, 4),
(5, 4),
(3, 5),
(4, 5);

-- COMMENTS
INSERT INTO Comments VALUES
(1, 1, 2, 'Nice pic!', '2023-05-01'),
(2, 2, 3, 'Congrats!', '2023-05-02'),
(3, 2, 4, 'Amazing effort!', '2023-05-02'),
(4, 4, 5, 'Python all the way!', '2023-05-04'),
(5, 5, 1, 'Great article!', '2023-05-05');

-- LIKES
INSERT INTO Likes VALUES
(1, 1, 2, '2023-05-01'),
(2, 1, 3, '2023-05-01'),
(3, 2, 4, '2023-05-02'),
(4, 2, 5, '2023-05-02'),
(5, 2, 1, '2023-05-02'),
(6, 3, 2, '2023-05-03'),
(7, 4, 3, '2023-05-04'),
(8, 4, 4, '2023-05-04'),
(9, 5, 5, '2023-05-05');
