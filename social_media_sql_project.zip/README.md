
# Social Media SQL Project

This project simulates a basic social media platform using SQL. It includes the following tables:

- `Users`: User info and join date
- `Posts`: Posts made by users
- `Followers`: Follower-followed relationships
- `Comments`: Comments on posts
- `Likes`: Likes on posts

## Sample Data

Includes sample users: Deva, Nataraj, Vicky, Yuvaraj, and Suman.

## Example Insights

- Top 3 most liked posts
- Most followed users
- Users with most posts/comments
- Engagement analysis

## How to Use

1. Import the `social_media_insights.sql` file into your SQL environment (e.g., SSMS).
2. Run the script to create and populate the database.
3. Start querying and exploring!

## Tools

- SQL Server Management Studio (SSMS)
